/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lynn;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author joyce00
 */
@WebServlet(name = "Enroll", urlPatterns = {"/Enroll"})
public class Enroll extends HttpServlet {
    private Connection conn;
    private Statement st;
    private ResultSet rs;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    public void init() {
    try {
      Class.forName("org.apache.derby.jdbc.ClientDriver"); 
      String connectionURL = "jdbc:derby://localhost:1527/LinLing";
      conn = DriverManager.getConnection(connectionURL, "IS2560", "IS2560");
    } catch (SQLException se) {
      se.printStackTrace();
    } catch (ClassNotFoundException ex) {
          ex.printStackTrace();
      }
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        response.setContentType("text/html;charset=UTF-8");

        HttpSession session=request.getSession(true);
        studentbean sb2 = new studentbean();
        session.setAttribute("sb2",sb2);   
        
      String[] pValue1 = request.getParameterValues("studentfn");
      String studentfn = pValue1[0];
      String[] pValue2 = request.getParameterValues("studentln");
      String studentln = pValue2[0];
      String[] pValue3 = request.getParameterValues("studentID2");
      String studentID = pValue3[0];
      String[] pValue4 = request.getParameterValues("studentemail");
      String email = pValue4[0];
      String[] pValue5 = request.getParameterValues("password2");
      String password = pValue5[0];  
      String[] pValue6 = request.getParameterValues("major");
      String major = pValue6[0]; 
      //Cookie ck = new Cookie("stuID", stuID);//creating cookie object  
     // response.addCookie(ck);//adding cookie in the response  
        
      // String ir = "insert into student values('mmm239', 'Information Science', 'Bob', 'Smith', 'mmm235@pitt.edu', '123')";
       String ir = "Insert into student values('"+studentID;
       ir+="','"+major+"','+";
       ir+=studentfn+"','"+studentln+"','"+email+"','"+password+"')";
     //  String ir=new String("SELECT* FROM STUDENT");
      st = conn.createStatement();
      st.execute(ir);
       
       
     
                                sb2.setEmail(email);
                                sb2.setFname(studentfn);
                                sb2.setLname(studentln);
                                sb2.setId(studentID);
                                sb2.setMajor(major);
                                sb2.setPassword(password);

       
       st.close();
       RequestDispatcher rd = getServletContext().getRequestDispatcher("/jsp1.jsp");
       rd.forward(request, response);
       /*
     try(PrintWriter out = response.getWriter()){
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Message Confirmation</title>");
        out.println("</head>");
        out.println("<body>");      
        out.println("<h3><a href =\"listMessages\">Click here for list</a></h3>");   
        //out.println("<h3><a href =\"listMessages\">Click here for greeting</a></h3>");  
        out.println("</body>");
        out.println("</html>");
     }
       */
      
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(Enroll.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(Enroll.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
