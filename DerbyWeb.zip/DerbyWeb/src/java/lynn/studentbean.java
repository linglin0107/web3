/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lynn;

/**
 *
 * @author joyce00
 */
import java.io.Serializable;

/**
 * @author spring
 */
public class studentbean extends Object implements Serializable {

    //public static final String ISTATUS = "Login";

    private String id, major, fname, lname, email, password;

    public studentbean() {
        id = new String();
        major = new String();
        fname = new String();
        lname = new String();
        email = new String();
        password = new String();
    }

    public String getId() {return id;}
    public void setId(String value) {id = value;}
    
    public String getMajor() {return major;}
    public void setMajor(String value) {major = value;}
    
    public String getFname() {return fname;}
    public void setFname(String value) {fname = value;}

    public String getLname() {return lname;}
    public void setLname(String value) {lname = value;}
    
    public String getEmail() {return email;}
    public void setEmail(String value) {email = value;}
 
    public String getPassword() {return password;}
    public void setPassword(String value) {password = value;}
}
