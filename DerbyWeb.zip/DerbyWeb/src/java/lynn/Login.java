/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lynn;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author joyce00
 */
@WebServlet(name = "Login", urlPatterns = {"/Login"})
public class Login extends HttpServlet {
    private Connection conn;
    private Statement st;
    private ResultSet rs;
    private String stuID;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    public void init() {
    try {
      Class.forName("org.apache.derby.jdbc.ClientDriver"); 
      String connectionURL = "jdbc:derby://localhost:1527/LinLing";
      conn = DriverManager.getConnection(connectionURL, "IS2560", "IS2560");
    } catch (SQLException se) {
      se.printStackTrace();
    } catch (ClassNotFoundException ex) {
          ex.printStackTrace();
      }
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        response.setContentType("text/html;charset=UTF-8");

        HttpSession session=request.getSession(true);
        studentbean sb = new studentbean();
        session.setAttribute("sb",sb);   
        
      String[] pValue1 = request.getParameterValues("studentID1");
      String studentID = pValue1[0];
      stuID = studentID;
      String[] pValue2 = request.getParameterValues("password");
      String password = pValue2[0];
        
      Cookie ck = new Cookie("stuID", stuID);//creating cookie object  
      response.addCookie(ck);//adding cookie in the response  
        
       //String ir = "insert into student values('mmm236', 'Information Science', 'Bob', 'Smith', 'mmm235@pitt.edu', '123')";
       String ir = "SELECT* FROM student WHERE id = '"+studentID+"'";
     //  String ir=new String("SELECT* FROM STUDENT");
       st = conn.createStatement();
       rs= st.executeQuery(ir);
       String id=null, major=null, fname=null, lname=null, email=null, passw=null;
       
       
       while (rs.next()) {
                                System.out.println("connect!");
				
				id = rs.getString("id");
                                major = rs.getString("major");
                                fname = rs.getString("First_name");
                                lname = rs.getString("Last_name");
                                email = rs.getString("email");
                                passw = rs.getString("password");
                                sb.setEmail(email);
                                sb.setFname(fname);
                                sb.setLname(lname);
                                sb.setId(id);
                                sb.setMajor(major);
                                sb.setPassword(passw);
					
			}
       
       st.close();
     //  RequestDispatcher rd = getServletContext().getRequestDispatcher("/jsp0.jsp");
     //  rd.forward(request, response);
       if(id!=null && passw.equals(password)){
           RequestDispatcher rd1 = getServletContext().getRequestDispatcher("/jsp0.jsp");
           rd1.forward(request, response);
       }
       else{
           RequestDispatcher rd2 = getServletContext().getRequestDispatcher("/jsp00.jsp");
           rd2.forward(request, response);
       }
    
    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
               
        
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
         
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
