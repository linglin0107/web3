/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lynn;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author joyce00
 */
@WebServlet(name = "listMyCourse", urlPatterns = {"/listMyCourse"})
public class listMyCourse extends HttpServlet {
     private String stuID;
     private Connection conn;
     private Statement st;
     private ResultSet rs;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
     
     public void init() {
    try {
      Class.forName("org.apache.derby.jdbc.ClientDriver"); 
      String connectionURL = "jdbc:derby://localhost:1527/LinLing";
      conn = DriverManager.getConnection(connectionURL, "IS2560", "IS2560");
    } catch (SQLException se) {
      se.printStackTrace();
    } catch (ClassNotFoundException ex) {
          ex.printStackTrace();
      }
    }
     
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        
        Cookie[] cookies = request.getCookies();
        stuID = cookies[0].getValue();
        
        HttpSession session=request.getSession(true);
        //listbean lb = new listbean();
        //session.setAttribute("lb",lb); 
        
        
        String ir = "select course.id, course.title From course, student_course";
                ir += " where course.id=student_course.courseID";
                ir += " and student_course.studentID='"+stuID+"'";
       //String ir=new String("SELECT* FROM STUDENT");
        st = conn.createStatement();
        rs= st.executeQuery(ir); 
        
        List<String> id = new ArrayList<>();
        List<String> title = new ArrayList<>();
         while (rs.next()) {
                                System.out.println("connect!");
				
				id.add(rs.getString("id"));
                                title.add(rs.getString("title"));					
			}

           // RequestDispatcher rd1 = getServletContext().getRequestDispatcher("/jsp2.jsp");
          //  rd1.forward(request, response);
          
           try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>ListCourse</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>StudentID: "+stuID+"</h1>");
            out.println("<h1>List of registered courses:</h1>");
            //out.println("<form >");
            //<input type="hidden" name="log" />
            out.println("<table border='1'>");
                out.println("<tbody>");
                   out.println("<tr>");
                         out.println("<td>courseID: </td>"); 
                         out.println("<td>courseTitle: </td>");
                       out.println("</tr>");
                   for(int i=0; i<id.size();i++){
                       out.println("<tr>");
                         out.println("<td>"+id.get(i)+"</td>"); 
                         out.println("<td>"+title.get(i)+"</td>");
                       out.println("</tr>");
                   }                  
                out.println("</tbody>");
            out.println("</table>");
            out.println("<br>");
            out.println("<form action='listAllCourse'>");
               out.println("<input type='submit' value='list of all courses'>");           
            out.println("</form>");
            out.println("<form action='homePage'>");
               out.println("<input type='submit' value='Back to home page!'>");           
            out.println("</form>");
          //out.println("</form>");
            out.println("</body>");
            out.println("</html>");
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         try {
             processRequest(request, response);
         } catch (SQLException ex) {
             Logger.getLogger(listMyCourse.class.getName()).log(Level.SEVERE, null, ex);
         }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         
         try {
             processRequest(request, response);
         } catch (SQLException ex) {
             Logger.getLogger(listMyCourse.class.getName()).log(Level.SEVERE, null, ex);
         }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
